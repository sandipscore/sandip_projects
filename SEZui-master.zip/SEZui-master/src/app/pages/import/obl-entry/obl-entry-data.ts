export const OBL_ENTRY_DATA = {
  containerCBTs: [
    { value: "Container", label: "Container" },
    { value: "CBT", label: "CBT" },
  ],
  containerCBTSizes: [
    { value: "20", label: "20" },
    { value: "40", label: "40" },
  ],
  movementTypes: [
    { value: "FCL", label: "FCL" },
    { value: "LCL", label: "LCL"}
  ]
};
