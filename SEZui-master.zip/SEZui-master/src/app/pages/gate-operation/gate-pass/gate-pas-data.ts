export const GATE_PASS_DATA = {
  cargoTypes: [
    { value: 1, label: "HAZ" },
    { value: 2, label: "Non HAZ" },
  ],
};
