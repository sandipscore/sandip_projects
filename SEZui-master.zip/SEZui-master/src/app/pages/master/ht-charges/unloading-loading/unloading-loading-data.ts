export const UNLOADING_LOADING_DATA = {
  operationTypes: [
    { value: "Import", label: "Import" },
    { value: "Export", label: "Export" },
  ]
};
