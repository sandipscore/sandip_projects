export const STORAGE_CHARGE_DATA = {
  arcaTypes: [
    { value: 1, label: "Gross" },
    { value: 2, label: "Net" },
  ],
  storageFors: [
    { value: 1, label: "Storage 1" },
    { value: 2, label: "Storage 2" },
  ],
  basisList: [
    { value: 1, label: "Basis 1" },
    { value: 2, label: "Basis 2" },
  ]
};
