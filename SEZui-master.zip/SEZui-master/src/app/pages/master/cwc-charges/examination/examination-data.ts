export const EXAMINATION_DATA = {
  examinationForOptions: [
    {label: "General", value: "General"},
    {label: "Import", value: "Import"},
    {label: "export", value: "export"},
  ]
};
