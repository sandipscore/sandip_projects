export const OPERATION_DATA = {
  types: [
    { value: "Import", label: "Import" },
    { value: "Import (RMS)", label: "Import (RMS)" },
    { value: "Export", label: "Export" },
    { value: "General", label: "General" },
  ]
};
