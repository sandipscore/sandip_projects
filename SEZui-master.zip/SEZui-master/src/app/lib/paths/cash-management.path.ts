export const CASH_MANAGEMENT_PATHS = {
  PAYMENT_RECEIPT: "payment-receipt",
};
