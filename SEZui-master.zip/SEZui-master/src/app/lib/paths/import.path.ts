export const IMPORT_PATHS = {
  OBL_ENTRY: "obl-entry",
  YARD_INVOICE: "yard-invoice",
  CUSTOM_APPRAISEMENT: "custom-appraisement",
};
