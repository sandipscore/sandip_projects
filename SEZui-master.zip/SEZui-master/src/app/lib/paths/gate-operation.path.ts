export const GATE_OPERATION_PATHS = {
  GATE_IN: "gate-in",
  GATE_EXIT: "gate-exit",
};
