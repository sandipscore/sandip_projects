export enum PARTY_TYPE {
  SHIPPING_LINE = "Shippingline",
  CHA="CHA",
}
