﻿namespace SezApi.Model
{
    public class CWCCharges
    {
    }
}
