export * from './delete-modal.component';
