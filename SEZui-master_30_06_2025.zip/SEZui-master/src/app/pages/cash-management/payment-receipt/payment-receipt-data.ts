export const PAYMENT_RECEIPT_DATA = {
  paymentModes: [
    { value: "Cash", label: "Cash" },
    { value: "NEFT", label: "NEFT" },
    { value: "CHEQUE", label: "CHEQUE" },
    { value: "DRAFT", label: "DRAFT" },
    { value: "PO", label: "PO" },
    { value: "CHALLAN", label: "CHALLAN" },
    { value: "CREDITNOTE", label: "CREDITNOTE" }
  ]
};
