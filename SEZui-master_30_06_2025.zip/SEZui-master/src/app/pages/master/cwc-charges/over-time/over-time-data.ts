export const OVER_TIME_DATA = {
  operationTypes: [
    { value: "Import", label: "Import" },
    { value: "Export", label: "Export" },
  ]
};
