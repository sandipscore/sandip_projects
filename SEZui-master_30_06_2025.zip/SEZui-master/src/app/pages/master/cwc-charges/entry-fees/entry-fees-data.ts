export const ENTRY_FEE_DATA = {
  operationTypes: [
    { value: "Import", label: "Import" },
    { value: "Export", label: "Export" },
  ]
};
