export const COMMODITY_DATA = {
    commodityTypes: [
      { value: "HAZ", label: "HAZ" },
      { value: "Non HAZ", label: "Non HAZ" },
    ]
};
