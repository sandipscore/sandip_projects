export const TRANSPORTATION_DATA = {
  applicableForList: [
    { value: 1, label: "Import" },
    { value: 2, label: "Export" },
    { value: 3, label: "Full Cash Van" },
  ],
  values: [
    { value: 1, label: "High" },
    { value: 2, label: "Low" },
  ]
};
