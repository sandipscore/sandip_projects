export const GATE_EXIT_DATA = {
  cargoTypes: [
    { value: 1, label: "HAZ" },
    { value: 2, label: "Non HAZ" },
  ],
  sizes: [
    { value: "20", label: "20" },
    { value: "40", label: "40" },
  ]
};
