export const ISSUER_DETAILS_DATA = {
  validTypes: [
    { value: "Open", label: "Open" },
    { value: "Closed", label: "Closed" },
  ]
};
