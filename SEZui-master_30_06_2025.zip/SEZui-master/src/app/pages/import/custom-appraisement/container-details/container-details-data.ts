export const CONTAINER_DETAILS_DATA = {
  sizes: [
    { value: "20", label: "20" },
    { value: "40", label: "40" },
  ],
  fclLclList: [
    { value: "FCL", label: "FCL" },
    { value: "LCL", label: "LCL"}
  ],
  containerCBTs: [
    { value: "Container", label: "Container" },
    { value: "CBT", label: "CBT" },
  ],
  cargoTypes: [],
  rmsList: [
    { value: "Exim", label: "Exim" },
    { value: "RMS Exim", label: "RMS Exim" },
    { value: "RMS Non Exim", label: "RMS Non Exim" },
  ],
};
