import { Routes } from '@angular/router';
import { ROUTES } from '.';

export const routes: Routes = ROUTES;
