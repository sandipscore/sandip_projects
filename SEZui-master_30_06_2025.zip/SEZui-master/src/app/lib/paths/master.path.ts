export const MASTER_PATHS = {
  COMMODITY: "commodity",
  EXIM_TRADER: "exim-trader",
  GODOWN: "godown",
  HT_CHARGES: {
    ROOT: "ht-charges",
    UNLOADING_LOADING: "unloading-loading",
    HANDLING: "handling",
    TRANSPORTATION: "transportation",
  },
  OPERATION: "operation",
  PORT: "port",
  SAC: "sac",
  CWC_CHARGES: {
    ROOT: "cwc-charges",
    ENTRY_FEES: "entry-fees",
    STORAGE_CHARGE: "storage-charge",
    INSURANCE_CHARGE: "insurance-charge",
    RENT_OFFICE_SPACE: "rent-office-space",
    RENT_TABLE_SPACE: "rent-table-space",
    OVER_TIME: "over-time",
    EXAMINATION: "examination",
  }
};
