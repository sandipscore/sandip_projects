export const environment = {
  apiBaseUrl: 'http://103.205.66.15:84',
};
